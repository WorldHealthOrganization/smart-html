# Can manage governance - TTL Representation - SMART Base v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can manage governance**

## : Can manage governance - TTL Representation

| |
| :--- |
| Draft as of 2026-08-27 |

[Raw ttl](Requirements-SGAuthoring.Skills.ManageGovernance.ttl) | [Download](Requirements-SGAuthoring.Skills.ManageGovernance.ttl)

