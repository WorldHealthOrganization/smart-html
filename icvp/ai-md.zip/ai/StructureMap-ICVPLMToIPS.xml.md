# ICVPLMToIPS - XML Representation - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **ICVPLMToIPS**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](StructureMap-ICVPLMToIPS.md) 
*  [XML](#) 
*  [JSON](StructureMap-ICVPLMToIPS.json.md) 
*  [TTL](StructureMap-ICVPLMToIPS.ttl.md) 

## : ICVPLMToIPS - XML Representation

| |
| :--- |
| Draft as of 2025-10-08 |

[Raw xml](StructureMap-ICVPLMToIPS.xml) | [Download](StructureMap-ICVPLMToIPS.xml)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

