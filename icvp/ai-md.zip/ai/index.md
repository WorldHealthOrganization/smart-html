# Home - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* **Home**

Publication Build: This will be filled in by the publication tooling

## Home

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/ImplementationGuide/smart.who.int.icvp | *Version*:0.2.0 |
| Draft as of 2025-10-08 | *Computable Name*:ICVP |

This WHO ICVP Implementation Guide details how to use Health Level 7 (HL7) Fast Healthcare Interoperability Resources (FHIR) for consistent digital representation of ICVP services.

 This implementation guide and set of artifacts are still undergoing development. 

 Content is for demonstration purposes only. 

### Disclaimer

The specification herewith documented is a demo working specification and may not be used for any implementation purposes. This draft is provided without warranty of completeness or consistency and the official publication supersedes this draft. No liability can be inferred from the use or misuse of this specification or its consequences.

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

