# ICVP - Vaccine Details - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **ICVP - Vaccine Details**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ICVPVaccineDetails-definitions.md) 
*  [Mappings](StructureDefinition-ICVPVaccineDetails-mappings.md) 
*  [XML](StructureDefinition-ICVPVaccineDetails.profile.xml.md) 
*  [JSON](StructureDefinition-ICVPVaccineDetails.profile.json.md) 
*  [TTL](StructureDefinition-ICVPVaccineDetails.profile.ttl.md) 

## Logical Model: ICVP - Vaccine Details ( Experimental ) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/StructureDefinition/ICVPVaccineDetails | *Version*:0.2.0 |
| Active as of 2025-10-08 | *Computable Name*:ICVPVaccineDetails |

 
Vaccine Data elements for the International Certificate of Vaccination or Prophylaxis 

**Usages:**

* Derived from this Logical Model: [ICVP Vaccine Details with Selective Disclosure](StructureDefinition-ICVPVaccineDetailsSD.md) and [pICVP - Vaccine Details](StructureDefinition-pICVPVaccineDetails.md)
* Use this Logical Model: [ICVP](StructureDefinition-ICVP.md) and [DVC Icvp with Selective Disclosure](StructureDefinition-ICVPSD.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.icvp|current/StructureDefinition/ICVPVaccineDetails)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Constraints

This structure is derived from [PreQualVaccineDetails](http://smart.who.int/trust-phw/v0.1.0/StructureDefinition-PreQualVaccineDetails.html) 

#### Constraints

#### Constraints

This structure is derived from [PreQualVaccineDetails](http://smart.who.int/trust-phw/v0.1.0/StructureDefinition-PreQualVaccineDetails.html) 

**Summary**

 **Key Elements View** 

#### Constraints

 **Differential View** 

This structure is derived from [PreQualVaccineDetails](http://smart.who.int/trust-phw/v0.1.0/StructureDefinition-PreQualVaccineDetails.html) 

#### Constraints

 **Snapshot View** 

#### Constraints

This structure is derived from [PreQualVaccineDetails](http://smart.who.int/trust-phw/v0.1.0/StructureDefinition-PreQualVaccineDetails.html) 

**Summary**

 

Other representations of profile: [CSV](StructureDefinition-ICVPVaccineDetails.csv), [Excel](StructureDefinition-ICVPVaccineDetails.xlsx) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

