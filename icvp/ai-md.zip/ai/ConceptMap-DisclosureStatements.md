# Discloure Statement maapings - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Discloure Statement maapings**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](ConceptMap-DisclosureStatements.xml.md) 
*  [JSON](ConceptMap-DisclosureStatements.json.md) 
*  [TTL](ConceptMap-DisclosureStatements.ttl.md) 

## ConceptMap: Discloure Statement maapings 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/ConceptMap/DisclosureStatements | *Version*:0.2.0 |
| Active as of 2025-10-08 | *Computable Name*:DisclosureStatements |

 
Mapping from Disclosure Statements to itself to show relatiohships 

Mapping from (not specified) to (not specified)

**Group 1**Mapping from [Discloure Statement maapings](ConceptMap-DisclosureStatements.md) to [Discloure Statement maapings](ConceptMap-DisclosureStatements.md)

* **Source Code**: disclose-icvp-narrative
  * **Relationship**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Target Code**: disclose-icvp
* **Source Code**: disclose-icvp-demographic
  * **Relationship**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Target Code**: disclose-icvp
* **Source Code**: disclose-icvp-demographic-narrative
  * **Relationship**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Target Code**: disclose-icvp-demographic
* **Source Code**: disclose-icvp-demographic-name
  * **Relationship**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Target Code**: disclose-icvp-demographic
* **Source Code**: disclose-icvp-demographic-dob
  * **Relationship**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Target Code**: disclose-icvp-demographic
* **Source Code**: disclose-icvp-demographic-nationality
  * **Relationship**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Target Code**: disclose-icvp-demographic
* **Source Code**: disclose-icvp-demographic-national-id
  * **Relationship**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Target Code**: disclose-icvp-demographic
* **Source Code**: disclose-icvp-vaccination
  * **Relationship**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Target Code**: disclose-icvp
* **Source Code**: disclose-icvp-vaccination-narrative
  * **Relationship**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Target Code**: disclose-icvp-vaccination
* **Source Code**: disclose-icvp-vaccination-clinician-name
  * **Relationship**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Target Code**: disclose-icvp-vaccination
* **Source Code**: disclose-icvp-vaccination-issuer
  * **Relationship**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Target Code**: disclose-icvp-vaccination

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

