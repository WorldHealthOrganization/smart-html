# ICVP - Vaccine Codes - XML Representation - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **ICVP - Vaccine Codes**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](ValueSet-ICVPVaccineCodes.md) 
*  [XML](#) 
*  [JSON](ValueSet-ICVPVaccineCodes.json.md) 
*  [TTL](ValueSet-ICVPVaccineCodes.ttl.md) 

## : ICVP - Vaccine Codes - XML Representation

| |
| :--- |
| Active as of 2025-10-08 |

[Raw xml](ValueSet-ICVPVaccineCodes.xml) | [Download](ValueSet-ICVPVaccineCodes.xml)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

