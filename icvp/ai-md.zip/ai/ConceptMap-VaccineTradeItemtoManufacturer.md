# ConceptMap from Vaccine Trade Item to Manufacturer - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **ConceptMap from Vaccine Trade Item to Manufacturer**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](ConceptMap-VaccineTradeItemtoManufacturer.xml.md) 
*  [JSON](ConceptMap-VaccineTradeItemtoManufacturer.json.md) 
*  [TTL](ConceptMap-VaccineTradeItemtoManufacturer.ttl.md) 

## ConceptMap: ConceptMap from Vaccine Trade Item to Manufacturer 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/ConceptMap/VaccineTradeItemtoManufacturer | *Version*:0.2.0 |
| Active as of 2025-10-08 | *Computable Name*:VaccineTradeItemtoManufacturer |

 
Mapping from Vaccine Trade Item to Manufacturer 

Mapping from (not specified) to (not specified)

**Group 1**Mapping from [preQualVaccines](ValueSet-preQualVaccines.md) to [VaccineManufacturer](ValueSet-VaccineManufacturer.md)

* **Source Code**: 95dd021427d11cc5b1e993a2346ae125
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: 9f078889f4903702762d00303f0ff713
* **Source Code**: ded6dc4f66c4eec9178bd13b7fdba477
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: 9f078889f4903702762d00303f0ff713
* **Source Code**: 42c7d74ee190836754548484817630fb
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: 9f078889f4903702762d00303f0ff713
* **Source Code**: a72d752a75badd7e33bb96f261eac666
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: 9f078889f4903702762d00303f0ff713
* **Source Code**: 7e6bac61531f2943ec146a5152f26de8
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: 9f078889f4903702762d00303f0ff713
* **Source Code**: 83b74943e21289d183eb515e4f69d62e
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: fca41003618e5d38b1d6e5d20833ca98
* **Source Code**: 2c594b69b8b6b5d4b77a22d7ef6ae760
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: fca41003618e5d38b1d6e5d20833ca98
* **Source Code**: a640b9f1e3bf870989c9f7498a0ae5a1
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: f18703fb02e156a8ae879e4216f6c561
* **Source Code**: 687886afca59bc5df06e1dd4c0613080
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: 51a62ec68a89ce14cf95679495b66719
* **Source Code**: 4e129a70f41a1880e67260e06b25330c
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: 51a62ec68a89ce14cf95679495b66719
* **Source Code**: b16c68782d6fcb1e171cae388f96083a
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: 51a62ec68a89ce14cf95679495b66719

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

