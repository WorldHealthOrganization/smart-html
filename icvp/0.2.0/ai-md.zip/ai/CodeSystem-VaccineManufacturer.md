# Prequalified Vaccines - Manufacturer names - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Prequalified Vaccines - Manufacturer names**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](CodeSystem-VaccineManufacturer.xml.md) 
*  [JSON](CodeSystem-VaccineManufacturer.json.md) 
*  [TTL](CodeSystem-VaccineManufacturer.ttl.md) 

## CodeSystem: Prequalified Vaccines - Manufacturer names 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/CodeSystem/VaccineManufacturer | *Version*:0.2.0 |
| Active as of 2025-10-08 | *Computable Name*:VaccineManufacturer |

 
List of WHO Prequalified Vaccines - Manufacturer names 

 This Code system is referenced in the content logical definition of the following value sets: 

* [VaccineManufacturer](ValueSet-VaccineManufacturer.md)

This code system `http://smart.who.int/icvp/CodeSystem/VaccineManufacturer` defines the following codes:

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

