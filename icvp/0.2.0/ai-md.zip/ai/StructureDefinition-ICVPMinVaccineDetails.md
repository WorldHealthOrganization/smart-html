# ICVP HCERT Payload - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **ICVP HCERT Payload**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ICVPMinVaccineDetails-definitions.md) 
*  [Mappings](StructureDefinition-ICVPMinVaccineDetails-mappings.md) 
*  [XML](StructureDefinition-ICVPMinVaccineDetails.profile.xml.md) 
*  [JSON](StructureDefinition-ICVPMinVaccineDetails.profile.json.md) 
*  [TTL](StructureDefinition-ICVPMinVaccineDetails.profile.ttl.md) 

## Logical Model: ICVP HCERT Payload 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/StructureDefinition/ICVPMinVaccineDetails | *Version*:0.2.0 |
| Active as of 2025-10-08 | *Computable Name*:ICVPMinVaccineDetails |

 
Mininmial vaccine detail in DVC payload for use within an HCERT Payload using the ICVP Product Catalogue 

**Usages:**

* Use this Logical Model: [ICVP HCERT Payload](StructureDefinition-ICVPMin.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.icvp|current/StructureDefinition/ICVPMinVaccineDetails)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [DVCMinVaccineDetails](http://smart.who.int/trust-phw/v0.1.0/StructureDefinition-DVCMinVaccineDetails.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [DVCMinVaccineDetails](http://smart.who.int/trust-phw/v0.1.0/StructureDefinition-DVCMinVaccineDetails.html) 

**Summary**

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [DVCMinVaccineDetails](http://smart.who.int/trust-phw/v0.1.0/StructureDefinition-DVCMinVaccineDetails.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [DVCMinVaccineDetails](http://smart.who.int/trust-phw/v0.1.0/StructureDefinition-DVCMinVaccineDetails.html) 

**Summary**

 

Other representations of profile: [CSV](StructureDefinition-ICVPMinVaccineDetails.csv), [Excel](StructureDefinition-ICVPMinVaccineDetails.xlsx) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

