# preQualVaccines - TTL Representation - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **preQualVaccines**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](ValueSet-preQualVaccines.md) 
*  [XML](ValueSet-preQualVaccines.xml.md) 
*  [JSON](ValueSet-preQualVaccines.json.md) 
*  [TTL](#) 

## : preQualVaccines - TTL Representation

| |
| :--- |
| Active as of 2025-10-08 |

[Raw ttl](ValueSet-preQualVaccines.ttl) | [Download](ValueSet-preQualVaccines.ttl)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

