#  - SMART ICVP v0.2.0

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-ICVPMinVaccineDetails.md) 
*  [Detailed Descriptions](StructureDefinition-ICVPMinVaccineDetails-definitions.md) 
*  [Mappings](StructureDefinition-ICVPMinVaccineDetails-mappings.md) 
*  [XML](StructureDefinition-ICVPMinVaccineDetails.profile.xml.md) 
*  [JSON](StructureDefinition-ICVPMinVaccineDetails.profile.json.md) 
*  [TTL](StructureDefinition-ICVPMinVaccineDetails.profile.ttl.md) 

## Logical Model: ICVPMinVaccineDetails - Change History

| |
| :--- |
| Active as of 2025-10-08 |

Changes in the ICVPMinVaccineDetails logical model.

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

