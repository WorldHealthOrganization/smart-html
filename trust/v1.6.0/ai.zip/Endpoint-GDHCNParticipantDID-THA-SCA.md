# GDHCNParticipantDID-THA-SCA - WHO SMART Trust v1.6.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-THA-SCA**

## Endpoint: GDHCNParticipantDID-THA-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Thailand Trustlist (DID v2) - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:THA:SCA resolvable at https://tng-cdn.who.int/v2/trustlist/-/THA/SCA/did.json

**managingOrganization**: [Organization Thailand](Organization-GDHCNParticipant-THA.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:THA:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-THA-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Thailand Trustlist (DID v2) - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:THA:SCA\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/THA/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-THA"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:THA:SCA"
}

```
