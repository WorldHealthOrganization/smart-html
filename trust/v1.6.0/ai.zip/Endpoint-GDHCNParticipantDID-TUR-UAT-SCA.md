# GDHCNParticipantDID-TUR-UAT-SCA - WHO SMART Trust v1.6.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-TUR-UAT-SCA**

## Endpoint: GDHCNParticipantDID-TUR-UAT-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Türkiye Trustlist (DID v2) - UAT - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:TUR:SCA resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/TUR/SCA/did.json

**managingOrganization**: [Organization Türkiye](Organization-GDHCNParticipant-TUR-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:TUR:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-TUR-UAT-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Türkiye Trustlist (DID v2) - UAT - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:TUR:SCA\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/TUR/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-TUR-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:TUR:SCA"
}

```
