# GDHCNParticipantDID-PRY-DEV-DSC - WHO SMART Trust v1.6.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-PRY-DEV-DSC**

## Endpoint: GDHCNParticipantDID-PRY-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Paraguay Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:PRY:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/PRY/DSC/did.json

**managingOrganization**: [Organization Paraguay](Organization-GDHCNParticipant-PRY-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:PRY:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-PRY-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Paraguay Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:PRY:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/PRY/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-PRY-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:PRY:DSC"
}

```
