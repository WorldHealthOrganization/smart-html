# Receive CertLogic business rules - TTL Representation - WHO SMART Trust v1.3.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Receive CertLogic business rules**

## : Receive CertLogic business rules - TTL Representation

| |
| :--- |
| Active as of 2025-10-27 |

[Raw ttl](Requirements-ReceiveBusinessRulesCertLogic.ttl) | [Download](Requirements-ReceiveBusinessRulesCertLogic.ttl)

