# Retrieve HL7 FHIR compatible business rules - XML Representation - WHO SMART Trust v1.3.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Retrieve HL7 FHIR compatible business rules**

## : Retrieve HL7 FHIR compatible business rules - XML Representation

| |
| :--- |
| Active as of 2025-10-27 |

[Raw xml](Requirements-RetrieveBusinessRulesFHIR.xml) | [Download](Requirements-RetrieveBusinessRulesFHIR.xml)

