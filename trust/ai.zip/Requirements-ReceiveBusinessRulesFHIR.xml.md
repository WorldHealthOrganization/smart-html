# Receive HL7 FHIR business rules - XML Representation - WHO SMART Trust v1.3.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Receive HL7 FHIR business rules**

## : Receive HL7 FHIR business rules - XML Representation

| |
| :--- |
| Active as of 2025-10-27 |

[Raw xml](Requirements-ReceiveBusinessRulesFHIR.xml) | [Download](Requirements-ReceiveBusinessRulesFHIR.xml)

