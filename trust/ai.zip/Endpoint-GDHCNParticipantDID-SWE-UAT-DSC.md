# GDHCNParticipantDID-SWE-UAT-DSC - WHO SMART Trust v1.7.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-SWE-UAT-DSC**

## Endpoint: GDHCNParticipantDID-SWE-UAT-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Sweden Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:SWE:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/SWE/DSC/did.json

**managingOrganization**: [Organization Sweden](Organization-GDHCNParticipant-SWE-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:SWE:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-SWE-UAT-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Sweden Trustlist (DID v2) - UAT - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:SWE:DSC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/SWE/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-SWE-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:SWE:DSC"
}

```
