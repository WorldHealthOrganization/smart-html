# GDHCNParticipantDID-THA-UAT-DSC - WHO SMART Trust v1.7.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-THA-UAT-DSC**

## Endpoint: GDHCNParticipantDID-THA-UAT-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Thailand Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:THA:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/THA/DSC/did.json

**managingOrganization**: [Organization Thailand](Organization-GDHCNParticipant-THA-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:THA:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-THA-UAT-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Thailand Trustlist (DID v2) - UAT - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:THA:DSC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/THA/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-THA-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:THA:DSC"
}

```
