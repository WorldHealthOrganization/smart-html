# Issue Verifiable Digital Health Certificate - JSON Representation - WHO SMART Trust v1.3.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Issue Verifiable Digital Health Certificate**

## : Issue Verifiable Digital Health Certificate - JSON Representation

| |
| :--- |
| Active as of 2025-10-27 |

[Raw json](Requirements-IssuerVDHC.json) | [Download](Requirements-IssuerVDHC.json)

