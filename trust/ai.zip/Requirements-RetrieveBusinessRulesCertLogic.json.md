# Retrieve Cert Logic compatible business rules - JSON Representation - WHO SMART Trust v1.3.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Retrieve Cert Logic compatible business rules**

## : Retrieve Cert Logic compatible business rules - JSON Representation

| |
| :--- |
| Active as of 2025-10-27 |

[Raw json](Requirements-RetrieveBusinessRulesCertLogic.json) | [Download](Requirements-RetrieveBusinessRulesCertLogic.json)

