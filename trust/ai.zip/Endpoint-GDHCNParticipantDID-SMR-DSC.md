# GDHCNParticipantDID-SMR-DSC - WHO SMART Trust v1.7.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-SMR-DSC**

## Endpoint: GDHCNParticipantDID-SMR-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: San Marino Trustlist (DID v2) - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:SMR:DSC resolvable at https://tng-cdn.who.int/v2/trustlist/-/SMR/DSC/did.json

**managingOrganization**: [Organization San Marino](Organization-GDHCNParticipant-SMR.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:SMR:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-SMR-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "San Marino Trustlist (DID v2) - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:SMR:DSC\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/SMR/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-SMR"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:SMR:DSC"
}

```
