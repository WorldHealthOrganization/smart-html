# GDHCNParticipantDID-XXJ-DEV-All - WHO SMART Trust v1.7.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXJ-DEV-All**

## Endpoint: GDHCNParticipantDID-XXJ-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: DEV Participant XXJ Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:XXJ resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXJ/did.json

**managingOrganization**: [Organization DEV Participant XXJ](Organization-GDHCNParticipant-XXJ-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXJ



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXJ-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "DEV Participant XXJ Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXJ\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXJ/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXJ-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXJ"
}

```
