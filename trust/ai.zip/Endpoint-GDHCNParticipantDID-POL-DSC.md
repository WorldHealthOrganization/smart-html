# GDHCNParticipantDID-POL-DSC - WHO SMART Trust v1.7.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-POL-DSC**

## Endpoint: GDHCNParticipantDID-POL-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Poland Trustlist (DID v2) - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:POL:DSC resolvable at https://tng-cdn.who.int/v2/trustlist/-/POL/DSC/did.json

**managingOrganization**: [Organization Poland](Organization-GDHCNParticipant-POL.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:POL:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-POL-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Poland Trustlist (DID v2) - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:POL:DSC\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/POL/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-POL"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:POL:DSC"
}

```
