# Publish PKI material - TTL Representation - WHO SMART Trust v1.3.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Publish PKI material**

## : Publish PKI material - TTL Representation

| |
| :--- |
| Active as of 2025-10-27 |

[Raw ttl](Requirements-PublishPKIMaterial.ttl) | [Download](Requirements-PublishPKIMaterial.ttl)

