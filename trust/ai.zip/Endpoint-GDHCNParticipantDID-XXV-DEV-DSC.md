# GDHCNParticipantDID-XXV-DEV-DSC - WHO SMART Trust v1.7.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXV-DEV-DSC**

## Endpoint: GDHCNParticipantDID-XXV-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: DEV Participant XXV Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:XXV:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXV/DSC/did.json

**managingOrganization**: [Organization DEV Participant XXV](Organization-GDHCNParticipant-XXV-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXV:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXV-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "DEV Participant XXV Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXV:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXV/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXV-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXV:DSC"
}

```
