# GDHCNParticipantDID-XXD-DEV-All - WHO SMART Trust v1.7.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXD-DEV-All**

## Endpoint: GDHCNParticipantDID-XXD-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: CENS XD Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:XXD resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXD/did.json

**managingOrganization**: [Organization CENS XD](Organization-GDHCNParticipant-XXD-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXD



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXD-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "CENS XD Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXD\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXD/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXD-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXD"
}

```
