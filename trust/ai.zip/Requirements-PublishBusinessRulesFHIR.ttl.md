# Publish HL7 FHIR business rules - TTL Representation - WHO SMART Trust v1.3.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Publish HL7 FHIR business rules**

## : Publish HL7 FHIR business rules - TTL Representation

| |
| :--- |
| Active as of 2025-10-27 |

[Raw ttl](Requirements-PublishBusinessRulesFHIR.ttl) | [Download](Requirements-PublishBusinessRulesFHIR.ttl)

