# GDHCNParticipantDID-MLT-UAT-DSC - WHO SMART Trust v1.7.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-MLT-UAT-DSC**

## Endpoint: GDHCNParticipantDID-MLT-UAT-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Malta Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:MLT:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/MLT/DSC/did.json

**managingOrganization**: [Organization Malta](Organization-GDHCNParticipant-MLT-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:MLT:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-MLT-UAT-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Malta Trustlist (DID v2) - UAT - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:MLT:DSC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/MLT/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-MLT-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:MLT:DSC"
}

```
