# Utilize a Verifiable Digital Health Certificate - TTL Representation - WHO SMART Trust v1.3.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Utilize a Verifiable Digital Health Certificate**

## : Utilize a Verifiable Digital Health Certificate - TTL Representation

| |
| :--- |
| Active as of 2025-10-27 |

[Raw ttl](Requirements-UtilizeVDHC.ttl) | [Download](Requirements-UtilizeVDHC.ttl)

