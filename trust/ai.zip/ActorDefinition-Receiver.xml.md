# Receiver - XML Representation - WHO SMART Trust v1.3.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Receiver**

## : Receiver - XML Representation

| |
| :--- |
| Active as of 2025-10-27 |

[Raw xml](ActorDefinition-Receiver.xml) | [Download](ActorDefinition-Receiver.xml)

