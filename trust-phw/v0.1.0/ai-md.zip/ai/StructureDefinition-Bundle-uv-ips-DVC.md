# DVC Certificate - DVC Bundle for Digital Vaccine Certificates - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC Certificate - DVC Bundle for Digital Vaccine Certificates**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-Bundle-uv-ips-DVC-definitions.md) 
*  [Mappings](StructureDefinition-Bundle-uv-ips-DVC-mappings.md) 
*  [XML](StructureDefinition-Bundle-uv-ips-DVC.profile.xml.md) 
*  [JSON](StructureDefinition-Bundle-uv-ips-DVC.profile.json.md) 
*  [TTL](StructureDefinition-Bundle-uv-ips-DVC.profile.ttl.md) 

## Resource Profile: DVC Certificate - DVC Bundle for Digital Vaccine Certificates 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/Bundle-uv-ips-DVC | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:Bundle-uv-ips-DVC |

 
Profile of the IPS Bundle for representing digital vaccination certificates 

**Usages:**

* Derived from this Profile: [DVC Certificate - IPS Bundle for WHO PreQual Databae](StructureDefinition-Bundle-uv-ips-PreQual.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/Bundle-uv-ips-DVC)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [BundleUvIps](http://hl7.org/fhir/uv/ips/2024Sep/StructureDefinition-Bundle-uv-ips.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [BundleUvIps](http://hl7.org/fhir/uv/ips/2024Sep/StructureDefinition-Bundle-uv-ips.html) 

**Summary**

**Structures**

This structure refers to these other structures:

* [DVC Certificate - IPS Composition(http://smart.who.int/trust-phw/StructureDefinition/Composition-uv-ips-DVC)](StructureDefinition-Composition-uv-ips-DVC.md)
* [DVC - Profile for Digitial Vaccination Cards for Immunization for IPS. Note that no Product Catalog has been set(http://smart.who.int/trust-phw/StructureDefinition/Immunization-uv-ips-DVC)](StructureDefinition-Immunization-uv-ips-DVC.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [BundleUvIps](http://hl7.org/fhir/uv/ips/2024Sep/StructureDefinition-Bundle-uv-ips.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [BundleUvIps](http://hl7.org/fhir/uv/ips/2024Sep/StructureDefinition-Bundle-uv-ips.html) 

**Summary**

**Structures**

This structure refers to these other structures:

* [DVC Certificate - IPS Composition(http://smart.who.int/trust-phw/StructureDefinition/Composition-uv-ips-DVC)](StructureDefinition-Composition-uv-ips-DVC.md)
* [DVC - Profile for Digitial Vaccination Cards for Immunization for IPS. Note that no Product Catalog has been set(http://smart.who.int/trust-phw/StructureDefinition/Immunization-uv-ips-DVC)](StructureDefinition-Immunization-uv-ips-DVC.md)

 

Other representations of profile: [CSV](StructureDefinition-Bundle-uv-ips-DVC.csv), [Excel](StructureDefinition-Bundle-uv-ips-DVC.xlsx), [Schematron](StructureDefinition-Bundle-uv-ips-DVC.sch) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

