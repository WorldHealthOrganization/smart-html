# Health Link Payload (DRAFT) - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Health Link Payload (DRAFT)**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-HealthLinkPayload-definitions.md) 
*  [Mappings](StructureDefinition-HealthLinkPayload-mappings.md) 
*  [XML](StructureDefinition-HealthLinkPayload.profile.xml.md) 
*  [JSON](StructureDefinition-HealthLinkPayload.profile.json.md) 
*  [TTL](StructureDefinition-HealthLinkPayload.profile.ttl.md) 

## Logical Model: Health Link Payload (DRAFT) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/HealthLinkPayload | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:HealthLinkPayload |

 
Health Link Payload (DRAFT) 
A Health Link URI is generated from this payload according to the algorithm documented[here](https://build.fhir.org/ig/HL7/smart-health-cards-and-links/links-specification.html#smart-health-links-sharing-application-generates-a-smart-health-link-uri) 

**Usages:**

* Derived from this Logical Model: [SMART Health Link Payload (DRAFT)](StructureDefinition-SMARTHealthLinkPayload.md) and [Verifiable Health Link Payload (DRAFT)](StructureDefinition-VerifiableHealthLinkPayload.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/HealthLinkPayload)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(2 nested mandatory elements)

 **Key Elements View** 

 **Differential View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

 **Snapshot View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(2 nested mandatory elements)

 

Other representations of profile: [CSV](StructureDefinition-HealthLinkPayload.csv), [Excel](StructureDefinition-HealthLinkPayload.xlsx) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

