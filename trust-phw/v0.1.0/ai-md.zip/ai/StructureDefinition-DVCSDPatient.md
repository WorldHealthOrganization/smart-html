# DVC Patient with Selective Disclosure - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC Patient with Selective Disclosure**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-DVCSDPatient-definitions.md) 
*  [Mappings](StructureDefinition-DVCSDPatient-mappings.md) 
*  [XML](StructureDefinition-DVCSDPatient.profile.xml.md) 
*  [JSON](StructureDefinition-DVCSDPatient.profile.json.md) 
*  [TTL](StructureDefinition-DVCSDPatient.profile.ttl.md) 

## Resource Profile: DVC Patient with Selective Disclosure 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/DVCSDPatient | *Version*:0.1.0 |
| Draft as of 2025-10-07 | *Computable Name*:DVCSDPatient |

 
DVC Patient with Selective Disclosure 

**Usages:**

* Use this Profile: [DVC document Bundle with Selective Disclosure](StructureDefinition-DVCSDBundle.md)
* Refer to this Profile: [Digital Vaccination Certificate - Composition](StructureDefinition-DVCSDComposition.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/DVCSDPatient)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [DVCPatient](StructureDefinition-DVCPatient.md) 

#### Terminology Bindings

#### Constraints

This structure is derived from [DVCPatient](StructureDefinition-DVCPatient.md) 

**Summary**

**Extensions**

This structure refers to these extensions:

* [http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure](StructureDefinition-SelectiveDisclosure.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [DVCPatient](StructureDefinition-DVCPatient.md) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [DVCPatient](StructureDefinition-DVCPatient.md) 

**Summary**

**Extensions**

This structure refers to these extensions:

* [http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure](StructureDefinition-SelectiveDisclosure.md)

 

Other representations of profile: [CSV](StructureDefinition-DVCSDPatient.csv), [Excel](StructureDefinition-DVCSDPatient.xlsx), [Schematron](StructureDefinition-DVCSDPatient.sch) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

