# DoseNumberCodeableConcept - Definitions - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DoseNumberCodeableConcept**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-DoseNumberCodeableConcept.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-DoseNumberCodeableConcept-mappings.md) 
*  [XML](StructureDefinition-DoseNumberCodeableConcept.profile.xml.md) 
*  [JSON](StructureDefinition-DoseNumberCodeableConcept.profile.json.md) 
*  [TTL](StructureDefinition-DoseNumberCodeableConcept.profile.ttl.md) 

## Extension: DoseNumberCodeableConcept - Detailed Descriptions

| |
| :--- |
| Draft as of 2025-10-07 |

Definitions for the DoseNumberCodeableConcept extension.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

