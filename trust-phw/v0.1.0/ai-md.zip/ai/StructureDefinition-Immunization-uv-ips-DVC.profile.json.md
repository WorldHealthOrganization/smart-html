# DVC - Profile for Digitial Vaccination Cards for Immunization for IPS. Note that no Product Catalog has been set - JSON Representation - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC - Profile for Digitial Vaccination Cards for Immunization for IPS. Note that no Product Catalog has been set**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-Immunization-uv-ips-DVC.md) 
*  [Detailed Descriptions](StructureDefinition-Immunization-uv-ips-DVC-definitions.md) 
*  [Mappings](StructureDefinition-Immunization-uv-ips-DVC-mappings.md) 
*  [XML](StructureDefinition-Immunization-uv-ips-DVC.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-Immunization-uv-ips-DVC.profile.ttl.md) 

## Resource Profile: Immunization-uv-ips-DVC - JSON Profile

| |
| :--- |
| Active as of 2025-10-07 |

JSON representation of the Immunization-uv-ips-DVC resource profile.

[Raw json](StructureDefinition-Immunization-uv-ips-DVC.json) | [Download](StructureDefinition-Immunization-uv-ips-DVC.json)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

