# DoseNumberCodeableConcept - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DoseNumberCodeableConcept**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-DoseNumberCodeableConcept-definitions.md) 
*  [Mappings](StructureDefinition-DoseNumberCodeableConcept-mappings.md) 
*  [XML](StructureDefinition-DoseNumberCodeableConcept.profile.xml.md) 
*  [JSON](StructureDefinition-DoseNumberCodeableConcept.profile.json.md) 
*  [TTL](StructureDefinition-DoseNumberCodeableConcept.profile.ttl.md) 

## Extension: DoseNumberCodeableConcept 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/DoseNumberCodeableConcept | *Version*:0.1.0 |
| Draft as of 2025-10-07 | *Computable Name*:DoseNumberCodeableConcept |

Dose Number

**Context of Use**

**Usage info**

**Usages:**

* This Extension is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/DoseNumberCodeableConcept)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type CodeableConcept: Dose Number

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type CodeableConcept: Dose Number

 

Other representations of profile: [CSV](StructureDefinition-DoseNumberCodeableConcept.csv), [Excel](StructureDefinition-DoseNumberCodeableConcept.xlsx), [Schematron](StructureDefinition-DoseNumberCodeableConcept.sch) 

#### Constraints

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

