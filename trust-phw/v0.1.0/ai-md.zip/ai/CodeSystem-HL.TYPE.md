# HL Type CodeSystem - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **HL Type CodeSystem**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](CodeSystem-HL.TYPE.xml.md) 
*  [JSON](CodeSystem-HL.TYPE.json.md) 
*  [TTL](CodeSystem-HL.TYPE.ttl.md) 

## CodeSystem: HL Type CodeSystem (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/CodeSystem/HL.TYPE | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:HL_TYPE |

 
CodeSystem for Health Link Type that has codes classifying type of Smart Health Link 

 This Code system is referenced in the content logical definition of the following value sets: 

* [HL_TYPE](ValueSet-HL.TYPE.md)

This case-insensitive code system `http://smart.who.int/trust-phw/CodeSystem/HL.TYPE` defines the following codes:

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

