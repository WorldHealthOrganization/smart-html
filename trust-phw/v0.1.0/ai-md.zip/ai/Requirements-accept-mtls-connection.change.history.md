#  - GDHCN Trust Network - Personal Health Wallet v0.1.0

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](Requirements-accept-mtls-connection.md) 
*  [XML](Requirements-accept-mtls-connection.xml.md) 
*  [JSON](Requirements-accept-mtls-connection.json.md) 
*  [TTL](Requirements-accept-mtls-connection.ttl.md) 

## : Requirements/accept-mtls-connection - Change History

History of changes for accept-mtls-connection .

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

