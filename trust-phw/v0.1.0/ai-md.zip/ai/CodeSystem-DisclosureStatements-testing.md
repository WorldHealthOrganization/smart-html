# Disclosure Statements - Testing - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Disclosure Statements**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](CodeSystem-DisclosureStatements.md) 
*  [XML](CodeSystem-DisclosureStatements.xml.md) 
*  [JSON](CodeSystem-DisclosureStatements.json.md) 
*  [TTL](CodeSystem-DisclosureStatements.ttl.md) 

## CodeSystem: Disclosure Statements - Testing 

| |
| :--- |
| Active as of 2025-10-07 |

### Test Plans

**No test plans are currently available for the CodeSystem.**

### Test Scripts

**No test scripts are currently available for the CodeSystem.**

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

