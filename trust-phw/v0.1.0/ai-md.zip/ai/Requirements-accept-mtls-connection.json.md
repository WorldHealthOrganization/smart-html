# Accept mTLS - JSON Representation - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Accept mTLS**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](Requirements-accept-mtls-connection.md) 
*  [XML](Requirements-accept-mtls-connection.xml.md) 
*  [JSON](#) 
*  [TTL](Requirements-accept-mtls-connection.ttl.md) 

## : Accept mTLS - JSON Representation

| |
| :--- |
| Active as of 2025-10-07 |

[Raw json](Requirements-accept-mtls-connection.json) | [Download](Requirements-accept-mtls-connection.json)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

