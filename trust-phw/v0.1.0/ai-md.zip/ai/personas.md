# Generic Personas - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Business Requirements**](business-requirements.md)
* **Generic Personas**

Publication Build: This will be filled in by the publication tooling

## Generic Personas

This page includes a depiction of end-users and related stakeholders as introduced in the WHO Digital Adaptation Kit for **[insert health domain here]**(link forthcoming).

The specific roles and demographic profile of the personas will vary depending on the setting, the generic personas are based on the WHO core competencies and credentials of different health worker personas.

### Targeted generic personas

The targeted personas for the **[insert health domain here]** Digital Adaptation Kit are health professionals operating in care settings that are able to provide the required essential interventions for **[insert health domain here]** delivery. Their key competences of are defined in the following table.

**Descriptions of key generic personas**

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

