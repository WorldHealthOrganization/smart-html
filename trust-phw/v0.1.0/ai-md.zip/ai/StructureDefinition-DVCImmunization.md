# DVC Immunization - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC Immunization**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-DVCImmunization-definitions.md) 
*  [Mappings](StructureDefinition-DVCImmunization-mappings.md) 
*  [XML](StructureDefinition-DVCImmunization.profile.xml.md) 
*  [JSON](StructureDefinition-DVCImmunization.profile.json.md) 
*  [TTL](StructureDefinition-DVCImmunization.profile.ttl.md) 

## Resource Profile: DVC Immunization 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/DVCImmunization | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:DVCImmunization |

 
This profile represents a vaccination record for Digital Vaccine Certificates 

**Usages:**

* Derived from this Profile: [DVC Immunization with Selective Disclosure](StructureDefinition-DVCSDImmunization.md)
* Use this Profile: [Digital Vaccination Certificate - Bundle](StructureDefinition-DVCBundle.md)
* Refer to this Profile: [Digital Vaccination Certificate - Composition](StructureDefinition-DVCComposition.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/DVCImmunization)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Immunization](http://hl7.org/fhir/R4/immunization.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Immunization](http://hl7.org/fhir/R4/immunization.html) 

**Summary**

Mandatory: 2 elements
 Must-Support: 2 elements

**Structures**

This structure refers to these other structures:

* [mCSD Practitioner(https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Practitioner)](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Practitioner.html)
* [mCSD Organization for Jurisdictions(https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.JurisdictionOrganization)](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.JurisdictionOrganization.html)

**Extensions**

This structure refers to these extensions:

* [http://smart.who.int/pcmt/StructureDefinition/ProductID](http://smart.who.int/pcmt/v0.1.0/StructureDefinition-ProductID.html)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Immunization](http://hl7.org/fhir/R4/immunization.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Immunization](http://hl7.org/fhir/R4/immunization.html) 

**Summary**

Mandatory: 2 elements
 Must-Support: 2 elements

**Structures**

This structure refers to these other structures:

* [mCSD Practitioner(https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Practitioner)](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Practitioner.html)
* [mCSD Organization for Jurisdictions(https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.JurisdictionOrganization)](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.JurisdictionOrganization.html)

**Extensions**

This structure refers to these extensions:

* [http://smart.who.int/pcmt/StructureDefinition/ProductID](http://smart.who.int/pcmt/v0.1.0/StructureDefinition-ProductID.html)

 

Other representations of profile: [CSV](StructureDefinition-DVCImmunization.csv), [Excel](StructureDefinition-DVCImmunization.xlsx), [Schematron](StructureDefinition-DVCImmunization.sch) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

