# DVCDocExample - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVCDocExample**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](Bundle-DVCDocExample.xml.md) 
*  [JSON](Bundle-DVCDocExample.json.md) 
*  [TTL](Bundle-DVCDocExample.ttl.md) 

## Example Bundle: DVCDocExample

**Document Details**

Language: en-GB

Profile: [Digital Vaccination Certificate - Bundle](StructureDefinition-DVCBundle.md)

Final Document at 2017-12-11 14:30:00+0100 by `urn:uuid:1c616b24-3895-48c4-9a02-9a64110351ef` for [Test Patient(official) Female, DoB: 2023-02-04 ( Passport number)](Bundle-DVCDocExample.md#urn-uuid-175863f7-fdea-4d11-92ff-f33345a560e4) 

-------

**Document Subject**

Profile: [DVC Patient](StructureDefinition-DVCPatient.md)

Test Patient(official) Female, DoB: 2023-02-04 ( Passport number)

-------

-------

**Document Content**
To be added
-------

## Demographic information section

Sample patient

## Vaccination

Vaccination stuff

-------

## Additional Resources Included in Document

-------

Entry 2 - fullUrl = urn:uuid:175863f7-fdea-4d11-92ff-f33345a560e4

Resource Patient:

> 

Profile: [DVC Patient](StructureDefinition-DVCPatient.md)

Test Patient(official) Female, DoB: 2023-02-04 ( Passport number)
-------

-------

Entry 3 - fullUrl = urn:uuid:bc283f8f-7092-4cc1-9d4d-8928b0341d00

Resource Immunization:

> 

Profile: [DVC Immunization](StructureDefinition-DVCImmunization.md)

**ProductID**: PreQualProductIDs YellowFeverProductd2c75a15ed309658b3968519ddb31690: YellowFeverProductd2c75a15ed309658b3968519ddb31690**status**: Completed**vaccineCode**:XM0N24**lotNumber**: 67890**patient**:[Test Patient(official) Female, DoB: 2023-02-04 ( Passport number)](Bundle-DVCDocExample.md#urn-uuid-175863f7-fdea-4d11-92ff-f33345a560e4)**occurrence**: 2024-05-23

### Performers

| | |
| :--- | :--- |
| - | **Actor** |
| * | `urn:uuid:086a66bd-63d0-442a-900f-b540f6b8cebe` |


 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

