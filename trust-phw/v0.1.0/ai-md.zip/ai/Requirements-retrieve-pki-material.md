# Retrieve PKI material - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Retrieve PKI material**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](Requirements-retrieve-pki-material.xml.md) 
*  [JSON](Requirements-retrieve-pki-material.json.md) 
*  [TTL](Requirements-retrieve-pki-material.ttl.md) 

## Requirements: Retrieve PKI material 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/Requirements/retrieve-pki-material | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*: |

 
Retrieve PKI material from a distribution point 

These requirements apply to the following actors: 

* [Trust Network Participant](ActorDefinition-TrustNetworkParticipant.md)
* [Trust Network Anchor](ActorDefinition-TrustNetworkAnchor.md)

|
|

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

