# DVC Certificate - IPS Composition - TTL Representation - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC Certificate - IPS Composition**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-Composition-uv-ips-DVC.md) 
*  [Detailed Descriptions](StructureDefinition-Composition-uv-ips-DVC-definitions.md) 
*  [Mappings](StructureDefinition-Composition-uv-ips-DVC-mappings.md) 
*  [XML](StructureDefinition-Composition-uv-ips-DVC.profile.xml.md) 
*  [JSON](StructureDefinition-Composition-uv-ips-DVC.profile.json.md) 
*  [TTL](#) 

## Resource Profile: Composition-uv-ips-DVC - TTL Profile

| |
| :--- |
| Active as of 2025-10-07 |

TTL representation of the Composition-uv-ips-DVC resource profile.

[Raw ttl](StructureDefinition-Composition-uv-ips-DVC.ttl) | [Download](StructureDefinition-Composition-uv-ips-DVC.ttl)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

