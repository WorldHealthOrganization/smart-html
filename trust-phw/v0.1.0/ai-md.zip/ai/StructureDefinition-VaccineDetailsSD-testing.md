# DVC Vaccine Details with Selective Disclosure - Testing - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC Vaccine Details with Selective Disclosure**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-VaccineDetailsSD.md) 
*  [Detailed Descriptions](StructureDefinition-VaccineDetailsSD-definitions.md) 
*  [Mappings](StructureDefinition-VaccineDetailsSD-mappings.md) 
*  [XML](StructureDefinition-VaccineDetailsSD.profile.xml.md) 
*  [JSON](StructureDefinition-VaccineDetailsSD.profile.json.md) 
*  [TTL](StructureDefinition-VaccineDetailsSD.profile.ttl.md) 

## Logical Model: VaccineDetailsSD - Testing

| |
| :--- |
| Draft as of 2025-10-07 |

### Test Plans

**No test plans are currently available for the Profile.**

### Test Scripts

**No test scripts are currently available for the Profile.**

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

