# DVC - Vaccines - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC - Vaccines**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](ValueSet-DVCVaccines.xml.md) 
*  [JSON](ValueSet-DVCVaccines.json.md) 
*  [TTL](ValueSet-DVCVaccines.ttl.md) 

## ValueSet: DVC - Vaccines 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/ValueSet/DVCVaccines | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:DVCVaccines |

 
This value set includes codes from ICD 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

* Include these codes as defined in [`http://id.who.int/icd/release/11/mms`](http://terminology.hl7.org/6.5.0/CodeSystem-ICD11MMS.html) version Not Stated (use latest from terminology server)

 

### Expansion

No Expansion for this valueset (Unknown Code System)

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

