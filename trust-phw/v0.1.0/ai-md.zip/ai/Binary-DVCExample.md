# DVCExample - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVCExample**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 

## Example Binary: DVCExample

This content is an example of the [DVC](StructureDefinition-DVC.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/trust-phw/StructureDefinition/DVC",
  "name": "Test Patient",
  "dob": "2023-02-04",
  "sex": "female",
  "nationality": "IND",
  "vaccineDetails": [
    {
      "productID": {
        "code": "PolioVaccineOralOPVBivalProduct756b50d1047d7e92674342044a986a4e",
        "system": "http://smart.who.int/pcmt-vaxprequal/CodeSystem/PreQualProductIDs"
      },
      "date": "2024-01-23",
      "clinicianName": "DR. A",
      "batchNo": {
        "coding": [
          {
            "display": "12345"
          }
        ]
      },
      "validityPeriod": {
        "start": "2024-01-31"
      }
    }
  ]
}

```

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

