# Digital Vaccination Certificate - Bundle - JSON Representation - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Digital Vaccination Certificate - Bundle**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-DVCBundle.md) 
*  [Detailed Descriptions](StructureDefinition-DVCBundle-definitions.md) 
*  [Mappings](StructureDefinition-DVCBundle-mappings.md) 
*  [Examples](StructureDefinition-DVCBundle-examples.md) 
*  [XML](StructureDefinition-DVCBundle.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-DVCBundle.profile.ttl.md) 

## Resource Profile: DVCBundle - JSON Profile

| |
| :--- |
| Active as of 2025-10-07 |

JSON representation of the DVCBundle resource profile.

[Raw json](StructureDefinition-DVCBundle.json) | [Download](StructureDefinition-DVCBundle.json)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

