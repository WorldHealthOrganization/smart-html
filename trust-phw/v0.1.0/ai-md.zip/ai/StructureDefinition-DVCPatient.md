# DVC Patient - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC Patient**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-DVCPatient-definitions.md) 
*  [Mappings](StructureDefinition-DVCPatient-mappings.md) 
*  [XML](StructureDefinition-DVCPatient.profile.xml.md) 
*  [JSON](StructureDefinition-DVCPatient.profile.json.md) 
*  [TTL](StructureDefinition-DVCPatient.profile.ttl.md) 

## Resource Profile: DVC Patient 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/DVCPatient | *Version*:0.1.0 |
| Draft as of 2025-10-07 | *Computable Name*:DVCPatient |

 
DVC Patient 

**Usages:**

* Derived from this Profile: [DVC Patient with Selective Disclosure](StructureDefinition-DVCSDPatient.md)
* Use this Profile: [Digital Vaccination Certificate - Bundle](StructureDefinition-DVCBundle.md)
* Refer to this Profile: [Digital Vaccination Certificate - Composition](StructureDefinition-DVCComposition.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/DVCPatient)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Patient](http://hl7.org/fhir/R4/patient.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [Patient](http://hl7.org/fhir/R4/patient.html) 

**Summary**

Mandatory: 5 elements
 Must-Support: 10 elements

**Extensions**

This structure refers to these extensions:

* [http://hl7.org/fhir/StructureDefinition/patient-nationality](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-patient-nationality.html)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 2 is sliced based on the values of Patient.name

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Patient](http://hl7.org/fhir/R4/patient.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Patient](http://hl7.org/fhir/R4/patient.html) 

**Summary**

Mandatory: 5 elements
 Must-Support: 10 elements

**Extensions**

This structure refers to these extensions:

* [http://hl7.org/fhir/StructureDefinition/patient-nationality](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-patient-nationality.html)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 2 is sliced based on the values of Patient.name

 

Other representations of profile: [CSV](StructureDefinition-DVCPatient.csv), [Excel](StructureDefinition-DVCPatient.xlsx), [Schematron](StructureDefinition-DVCPatient.sch) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

