# System Actors - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Data Models and Exchange**](data-models-and-exchange.md)
* **System Actors**

Publication Build: This will be filled in by the publication tooling

## System Actors

* [Trust Anchor](#trust-anchor-)
* [Trust Network Participant](#trust-network-participant-)
* [Holder](#holder-)
* [Receiver](#receiver-)
* [Issuer](#issuer-)
* [Consent Registry](#consent-registry-)

### Trust Anchor 

Trust Anchor which receives and distributes PKI-material within a Trust Network

### Trust Network Participant 

Trust Network Participant which publishes and or receives PKI-material within a Trust Network

### Holder 

Holder (person) of [Verifiable Health Certificate](https://smart.who.int/trust/concepts.html#verifiable-digital-health-certificate) or [Verifiable Health Link](https://build.fhir.org/ig/IHE/ITI.VHL/branches/master/index.html)

### Receiver 

Receiver (system) of [Verifiable Health Certificate](https://smart.who.int/trust/concepts.html#verifiable-digital-health-certificate) or [Verifiable Health Link](https://build.fhir.org/ig/IHE/ITI.VHL/branches/master/index.html)

### Issuer 

Issuer (system) of [Verifiable Health Certificate](https://smart.who.int/trust/concepts.html#verifiable-digital-health-certificate) or [Verifiable Health Link](https://build.fhir.org/ig/IHE/ITI.VHL/branches/master/index.html)

### Consent Registry 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

