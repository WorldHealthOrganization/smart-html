# DVCDocSDExample - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVCDocSDExample**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](Bundle-DVCDocSDExample.xml.md) 
*  [JSON](Bundle-DVCDocSDExample.json.md) 
*  [TTL](Bundle-DVCDocSDExample.ttl.md) 

## Example Bundle: DVCDocSDExample

**Document Details**

Language: en-GB

Profile: [DVC document Bundle with Selective Disclosure](StructureDefinition-DVCSDBundle.md)

Final Document at 2017-12-11 14:30:00+0100 by `urn:uuid:1c616b24-3895-48c4-9a02-9a64110351ef` for [Test Patient(official) Female, DoB: 2023-02-04 ( Passport number)](Bundle-DVCDocSDExample.md#urn-uuid-157863f7-fdea-4d11-92ff-f33345a560e4) 

-------

**Document Subject**
Test Patient name and demographics

-------

**Document Content**
To be added
-------

## Patient

Sample patient

## Vaccination

Vaccination stuff

-------

## Additional Resources Included in Document

-------

Entry 2 - fullUrl = urn:uuid:157863f7-fdea-4d11-92ff-f33345a560e4

Resource Patient:

> Test Patient name and demographics

-------

Entry 3 - fullUrl = urn:uuid:bc283f8f-0279-4cc1-9d4d-8928b0341d00

Resource Immunization:

> vaccination event details

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

