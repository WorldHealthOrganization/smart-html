# SGActorExt - Mappings - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **SGActorExt**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-SGActorExt.md) 
*  [Detailed Descriptions](StructureDefinition-SGActorExt-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-SGActorExt.profile.xml.md) 
*  [JSON](StructureDefinition-SGActorExt.profile.json.md) 
*  [TTL](StructureDefinition-SGActorExt.profile.ttl.md) 

## Extension: SGActorExt - Mappings

| |
| :--- |
| Active as of 2025-10-07 |

Mappings for the SGActorExt extension.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

