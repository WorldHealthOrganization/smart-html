# DVC Patient with Selective Disclosure - Mappings - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC Patient with Selective Disclosure**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-DVCSDPatient.md) 
*  [Detailed Descriptions](StructureDefinition-DVCSDPatient-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-DVCSDPatient.profile.xml.md) 
*  [JSON](StructureDefinition-DVCSDPatient.profile.json.md) 
*  [TTL](StructureDefinition-DVCSDPatient.profile.ttl.md) 

## Resource Profile: DVCSDPatient - Mappings

| |
| :--- |
| Draft as of 2025-10-07 |

Mappings for the DVCSDPatient resource profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

