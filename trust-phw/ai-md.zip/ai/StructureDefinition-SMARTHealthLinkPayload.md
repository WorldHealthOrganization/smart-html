# SMART Health Link Payload (DRAFT) - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **SMART Health Link Payload (DRAFT)**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-SMARTHealthLinkPayload-definitions.md) 
*  [Mappings](StructureDefinition-SMARTHealthLinkPayload-mappings.md) 
*  [XML](StructureDefinition-SMARTHealthLinkPayload.profile.xml.md) 
*  [JSON](StructureDefinition-SMARTHealthLinkPayload.profile.json.md) 
*  [TTL](StructureDefinition-SMARTHealthLinkPayload.profile.ttl.md) 

## Logical Model: SMART Health Link Payload (DRAFT) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/SMARTHealthLinkPayload | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:SMARTHealthLinkPayload |

 
SMART Health Link Payload (DRAFT) 
This logical model constrains the Health Link Payload for a SMART Health Link 
A SMART Health Link URI is generated from this payload according to the algorithm documented[here](https://build.fhir.org/ig/HL7/smart-health-cards-and-links/links-specification.html#smart-health-links-sharing-application-generates-a-smart-health-link-uri) 

**Usages:**

* This Logical Model is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/SMARTHealthLinkPayload)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [HealthLinkPayload](StructureDefinition-HealthLinkPayload.md) 

This structure is derived from [HealthLinkPayload](StructureDefinition-HealthLinkPayload.md) 

**Summary**

Prohibited: 1 element

 **Key Elements View** 

 **Differential View** 

This structure is derived from [HealthLinkPayload](StructureDefinition-HealthLinkPayload.md) 

 **Snapshot View** 

This structure is derived from [HealthLinkPayload](StructureDefinition-HealthLinkPayload.md) 

**Summary**

Prohibited: 1 element

 

Other representations of profile: [CSV](StructureDefinition-SMARTHealthLinkPayload.csv), [Excel](StructureDefinition-SMARTHealthLinkPayload.xlsx) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

