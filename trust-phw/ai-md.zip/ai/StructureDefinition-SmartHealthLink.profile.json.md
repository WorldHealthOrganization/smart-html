# Smart Health Link (DRAFT) - JSON Representation - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Smart Health Link (DRAFT)**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-SmartHealthLink.md) 
*  [Detailed Descriptions](StructureDefinition-SmartHealthLink-definitions.md) 
*  [Mappings](StructureDefinition-SmartHealthLink-mappings.md) 
*  [XML](StructureDefinition-SmartHealthLink.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-SmartHealthLink.profile.ttl.md) 

## Logical Model: SmartHealthLink - JSON Profile

| |
| :--- |
| Active as of 2025-10-07 |

JSON representation of the SmartHealthLink logical model.

[Raw json](StructureDefinition-SmartHealthLink.json) | [Download](StructureDefinition-SmartHealthLink.json)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

