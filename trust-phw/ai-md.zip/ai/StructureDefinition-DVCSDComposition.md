# Digital Vaccination Certificate - Composition - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Digital Vaccination Certificate - Composition**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-DVCSDComposition-definitions.md) 
*  [Mappings](StructureDefinition-DVCSDComposition-mappings.md) 
*  [XML](StructureDefinition-DVCSDComposition.profile.xml.md) 
*  [JSON](StructureDefinition-DVCSDComposition.profile.json.md) 
*  [TTL](StructureDefinition-DVCSDComposition.profile.ttl.md) 

## Resource Profile: Digital Vaccination Certificate - Composition 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/DVCSDComposition | *Version*:0.1.0 |
| Draft as of 2025-10-07 | *Computable Name*:DVCSDComposition |

 
Digital Vaccination Certificate - Composition 

**Usages:**

* Use this Profile: [DVC document Bundle with Selective Disclosure](StructureDefinition-DVCSDBundle.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/DVCSDComposition)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [DVCComposition](StructureDefinition-DVCComposition.md) 

#### Terminology Bindings

#### Constraints

This structure is derived from [DVCComposition](StructureDefinition-DVCComposition.md) 

**Summary**

**Structures**

This structure refers to these other structures:

* [DVC Patient with Selective Disclosure(http://smart.who.int/trust-phw/StructureDefinition/DVCSDPatient)](StructureDefinition-DVCSDPatient.md)
* [DVC Immunization with Selective Disclosure(http://smart.who.int/trust-phw/StructureDefinition/DVCSDImmunization)](StructureDefinition-DVCSDImmunization.md)

**Extensions**

This structure refers to these extensions:

* [http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure](StructureDefinition-SelectiveDisclosure.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [DVCComposition](StructureDefinition-DVCComposition.md) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [DVCComposition](StructureDefinition-DVCComposition.md) 

**Summary**

**Structures**

This structure refers to these other structures:

* [DVC Patient with Selective Disclosure(http://smart.who.int/trust-phw/StructureDefinition/DVCSDPatient)](StructureDefinition-DVCSDPatient.md)
* [DVC Immunization with Selective Disclosure(http://smart.who.int/trust-phw/StructureDefinition/DVCSDImmunization)](StructureDefinition-DVCSDImmunization.md)

**Extensions**

This structure refers to these extensions:

* [http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure](StructureDefinition-SelectiveDisclosure.md)

 

Other representations of profile: [CSV](StructureDefinition-DVCSDComposition.csv), [Excel](StructureDefinition-DVCSDComposition.xlsx), [Schematron](StructureDefinition-DVCSDComposition.sch) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

