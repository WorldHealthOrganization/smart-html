# DVC document Bundle with Selective Disclosure - Examples - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC document Bundle with Selective Disclosure**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-DVCSDBundle.md) 
*  [Detailed Descriptions](StructureDefinition-DVCSDBundle-definitions.md) 
*  [Mappings](StructureDefinition-DVCSDBundle-mappings.md) 
*  [Examples](#) 
*  [XML](StructureDefinition-DVCSDBundle.profile.xml.md) 
*  [JSON](StructureDefinition-DVCSDBundle.profile.json.md) 
*  [TTL](StructureDefinition-DVCSDBundle.profile.ttl.md) 

## Resource Profile: DVCSDBundle - Examples

| |
| :--- |
| Active as of 2025-10-07 |

Examples for the DVCSDBundle Profile.

| |
| :--- |
| [DVCDocSDExample](Bundle-DVCDocSDExample.md) |

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

