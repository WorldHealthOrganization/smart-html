# Digital Vaccination Certificate - Bundle - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Digital Vaccination Certificate - Bundle**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-DVCBundle-definitions.md) 
*  [Mappings](StructureDefinition-DVCBundle-mappings.md) 
*  [Examples](StructureDefinition-DVCBundle-examples.md) 
*  [XML](StructureDefinition-DVCBundle.profile.xml.md) 
*  [JSON](StructureDefinition-DVCBundle.profile.json.md) 
*  [TTL](StructureDefinition-DVCBundle.profile.ttl.md) 

## Resource Profile: Digital Vaccination Certificate - Bundle 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/DVCBundle | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:DVCBundle |

 
Digital Vaccination Certificate - Bundle 

**Usages:**

* Derived from this Profile: [DVC document Bundle with Selective Disclosure](StructureDefinition-DVCSDBundle.md)
* Examples for this Profile: [Bundle/DVCDocExample](Bundle-DVCDocExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/DVCBundle)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

**Summary**

Mandatory: 8 elements
 Must-Support: 3 elements
 Fixed: 1 element

**Structures**

This structure refers to these other structures:

* [Digital Vaccination Certificate - Composition(http://smart.who.int/trust-phw/StructureDefinition/DVCComposition)](StructureDefinition-DVCComposition.md)
* [DVC Patient(http://smart.who.int/trust-phw/StructureDefinition/DVCPatient)](StructureDefinition-DVCPatient.md)
* [DVC Immunization(http://smart.who.int/trust-phw/StructureDefinition/DVCImmunization)](StructureDefinition-DVCImmunization.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 2 is sliced based on the values of Bundle.entry

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

**Summary**

Mandatory: 8 elements
 Must-Support: 3 elements
 Fixed: 1 element

**Structures**

This structure refers to these other structures:

* [Digital Vaccination Certificate - Composition(http://smart.who.int/trust-phw/StructureDefinition/DVCComposition)](StructureDefinition-DVCComposition.md)
* [DVC Patient(http://smart.who.int/trust-phw/StructureDefinition/DVCPatient)](StructureDefinition-DVCPatient.md)
* [DVC Immunization(http://smart.who.int/trust-phw/StructureDefinition/DVCImmunization)](StructureDefinition-DVCImmunization.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 2 is sliced based on the values of Bundle.entry

 

Other representations of profile: [CSV](StructureDefinition-DVCBundle.csv), [Excel](StructureDefinition-DVCBundle.xlsx), [Schematron](StructureDefinition-DVCBundle.sch) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

