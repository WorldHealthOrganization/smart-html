# DVC - Profile for Digitial Vaccination Cards for Immunization for IPS. Note that no Product Catalog has been set - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC - Profile for Digitial Vaccination Cards for Immunization for IPS. Note that no Product Catalog has been set**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-Immunization-uv-ips-DVC-definitions.md) 
*  [Mappings](StructureDefinition-Immunization-uv-ips-DVC-mappings.md) 
*  [XML](StructureDefinition-Immunization-uv-ips-DVC.profile.xml.md) 
*  [JSON](StructureDefinition-Immunization-uv-ips-DVC.profile.json.md) 
*  [TTL](StructureDefinition-Immunization-uv-ips-DVC.profile.ttl.md) 

## Resource Profile: DVC - Profile for Digitial Vaccination Cards for Immunization for IPS. Note that no Product Catalog has been set 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/Immunization-uv-ips-DVC | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:Immunization-uv-ips-DVC |

 
This profile represents an IPS Immunization record that can be mapped onto a Digital Vaccine Certificates using the WHO PreQual Database 

**Usages:**

* Derived from this Profile: [DVC - WHO PreQual Immunization for IPS](StructureDefinition-Immunization-uv-ips-PreQual.md)
* Use this Profile: [DVC Certificate - DVC Bundle for Digital Vaccine Certificates](StructureDefinition-Bundle-uv-ips-DVC.md)
* Refer to this Profile: [DVC Certificate - IPS Composition](StructureDefinition-Composition-uv-ips-DVC.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/Immunization-uv-ips-DVC)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [ImmunizationUvIps](http://hl7.org/fhir/uv/ips/2024Sep/StructureDefinition-Immunization-uv-ips.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [ImmunizationUvIps](http://hl7.org/fhir/uv/ips/2024Sep/StructureDefinition-Immunization-uv-ips.html) 

**Summary**

Mandatory: 2 elements
 Must-Support: 1 element

**Extensions**

This structure refers to these extensions:

* [http://smart.who.int/pcmt/StructureDefinition/ProductID](http://smart.who.int/pcmt/v0.1.0/StructureDefinition-ProductID.html)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [ImmunizationUvIps](http://hl7.org/fhir/uv/ips/2024Sep/StructureDefinition-Immunization-uv-ips.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [ImmunizationUvIps](http://hl7.org/fhir/uv/ips/2024Sep/StructureDefinition-Immunization-uv-ips.html) 

**Summary**

Mandatory: 2 elements
 Must-Support: 1 element

**Extensions**

This structure refers to these extensions:

* [http://smart.who.int/pcmt/StructureDefinition/ProductID](http://smart.who.int/pcmt/v0.1.0/StructureDefinition-ProductID.html)

 

Other representations of profile: [CSV](StructureDefinition-Immunization-uv-ips-DVC.csv), [Excel](StructureDefinition-Immunization-uv-ips-DVC.xlsx), [Schematron](StructureDefinition-Immunization-uv-ips-DVC.sch) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

