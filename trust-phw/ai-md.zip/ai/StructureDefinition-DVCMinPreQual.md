# DVCMinPreQual - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVCMinPreQual**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-DVCMinPreQual-definitions.md) 
*  [Mappings](StructureDefinition-DVCMinPreQual-mappings.md) 
*  [XML](StructureDefinition-DVCMinPreQual.profile.xml.md) 
*  [JSON](StructureDefinition-DVCMinPreQual.profile.json.md) 
*  [TTL](StructureDefinition-DVCMinPreQual.profile.ttl.md) 

## Logical Model: DVCMinPreQual 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/DVCMinPreQual | *Version*:0.1.0 |
| Draft as of 2025-10-07 | *Computable Name*:DVCMinPreQual |

 
DVC payload mininmized for use within an HCERT Payload with the WHO PreQual Vaccine Database 

**Usages:**

* This Logical Model is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/DVCMinPreQual)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

This structure is derived from [DVCMin](StructureDefinition-DVCMin.md) 

#### Terminology Bindings

This structure is derived from [DVCMin](StructureDefinition-DVCMin.md) 

**Summary**

 **Key Elements View** 

#### Terminology Bindings

 **Differential View** 

This structure is derived from [DVCMin](StructureDefinition-DVCMin.md) 

 **Snapshot View** 

#### Terminology Bindings

This structure is derived from [DVCMin](StructureDefinition-DVCMin.md) 

**Summary**

 

Other representations of profile: [CSV](StructureDefinition-DVCMinPreQual.csv), [Excel](StructureDefinition-DVCMinPreQual.xlsx) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

