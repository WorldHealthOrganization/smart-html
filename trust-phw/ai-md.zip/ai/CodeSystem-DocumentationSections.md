# Smart Guidelines Documentation Section - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Smart Guidelines Documentation Section**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](CodeSystem-DocumentationSections.xml.md) 
*  [JSON](CodeSystem-DocumentationSections.json.md) 
*  [TTL](CodeSystem-DocumentationSections.ttl.md) 

## CodeSystem: Smart Guidelines Documentation Section (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/CodeSystem/DocumentationSections | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:DocumentationSections |

 
CodeSystem for Smart Guidelines Documentation Section to autogenerate documentation from artifacts 

 This Code system is referenced in the content logical definition of the following value sets: 

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

This case-insensitive code system `http://smart.who.int/trust-phw/CodeSystem/DocumentationSections` defines the following codes:

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

