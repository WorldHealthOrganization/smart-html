# DVC - WHO PreQual Immunization for IPS - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC - WHO PreQual Immunization for IPS**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-Immunization-uv-ips-PreQual-definitions.md) 
*  [Mappings](StructureDefinition-Immunization-uv-ips-PreQual-mappings.md) 
*  [XML](StructureDefinition-Immunization-uv-ips-PreQual.profile.xml.md) 
*  [JSON](StructureDefinition-Immunization-uv-ips-PreQual.profile.json.md) 
*  [TTL](StructureDefinition-Immunization-uv-ips-PreQual.profile.ttl.md) 

## Resource Profile: DVC - WHO PreQual Immunization for IPS 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/Immunization-uv-ips-PreQual | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:Immunization-uv-ips-PreQual |

 
This profile represents an IPS Immunization record that can be mapped onto a Digital Vaccine Certificates using the WHO PreQual Database 

**Usages:**

* Use this Profile: [DVC Certificate - IPS Bundle for WHO PreQual Databae](StructureDefinition-Bundle-uv-ips-PreQual.md)
* Refer to this Profile: [DVC Certificate - IPS Composition for WHO PreQual Database](StructureDefinition-Composition-uv-ips-PreQual.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/Immunization-uv-ips-PreQual)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Immunization-uv-ips-DVC](StructureDefinition-Immunization-uv-ips-DVC.md) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Immunization-uv-ips-DVC](StructureDefinition-Immunization-uv-ips-DVC.md) 

**Summary**

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Immunization-uv-ips-DVC](StructureDefinition-Immunization-uv-ips-DVC.md) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Immunization-uv-ips-DVC](StructureDefinition-Immunization-uv-ips-DVC.md) 

**Summary**

 

Other representations of profile: [CSV](StructureDefinition-Immunization-uv-ips-PreQual.csv), [Excel](StructureDefinition-Immunization-uv-ips-PreQual.xlsx), [Schematron](StructureDefinition-Immunization-uv-ips-PreQual.sch) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

