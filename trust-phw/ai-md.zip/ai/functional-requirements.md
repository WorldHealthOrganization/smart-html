# Functional Requirements - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Business Requirements**](business-requirements.md)
* **Functional Requirements**

Publication Build: This will be filled in by the publication tooling

## Functional Requirements

Functional requirements describe the capabilities the system must have in order to meet the end-users’ needs and achieve tasks within the business process.

These requirements are taken from Component 8 and Web Annex D of the WHO Digital Adaptation Kit for **[insert health domain here]** (link forthcoming).

Please note that these are not exhaustive lists and should be modified according to context and user persona needs

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

