# PreQual - Vaccine Details - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual - Vaccine Details**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-PreQualVaccineDetails-definitions.md) 
*  [Mappings](StructureDefinition-PreQualVaccineDetails-mappings.md) 
*  [XML](StructureDefinition-PreQualVaccineDetails.profile.xml.md) 
*  [JSON](StructureDefinition-PreQualVaccineDetails.profile.json.md) 
*  [TTL](StructureDefinition-PreQualVaccineDetails.profile.ttl.md) 

## Logical Model: PreQual - Vaccine Details ( Experimental ) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/PreQualVaccineDetails | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:PreQualVaccineDetails |

 
Vaccine Data elements from the Pre Qual Database 

**Usages:**

* Use this Logical Model: [PreQual](StructureDefinition-PreQualDVC.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/PreQualVaccineDetails)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Constraints

This structure is derived from [VaccineDetails](StructureDefinition-VaccineDetails.md) 

#### Constraints

#### Constraints

This structure is derived from [VaccineDetails](StructureDefinition-VaccineDetails.md) 

**Summary**

 **Key Elements View** 

#### Constraints

 **Differential View** 

This structure is derived from [VaccineDetails](StructureDefinition-VaccineDetails.md) 

#### Constraints

 **Snapshot View** 

#### Constraints

This structure is derived from [VaccineDetails](StructureDefinition-VaccineDetails.md) 

**Summary**

 

Other representations of profile: [CSV](StructureDefinition-PreQualVaccineDetails.csv), [Excel](StructureDefinition-PreQualVaccineDetails.xlsx) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

