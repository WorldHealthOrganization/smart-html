# Accept mTLS - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Accept mTLS**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](Requirements-accept-mtls-connection.xml.md) 
*  [JSON](Requirements-accept-mtls-connection.json.md) 
*  [TTL](Requirements-accept-mtls-connection.ttl.md) 

## Requirements: Accept mTLS 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/Requirements/accept-mtls-connection | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*: |

 
Accept an mTLS in order to conduct further transactions under a secure channel 

These requirements apply to the actor [Issuer](ActorDefinition-Issuer.md)

|
|

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

