# Digital Vaccination Certificate - Composition - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Digital Vaccination Certificate - Composition**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-DVCComposition-definitions.md) 
*  [Mappings](StructureDefinition-DVCComposition-mappings.md) 
*  [XML](StructureDefinition-DVCComposition.profile.xml.md) 
*  [JSON](StructureDefinition-DVCComposition.profile.json.md) 
*  [TTL](StructureDefinition-DVCComposition.profile.ttl.md) 

## Resource Profile: Digital Vaccination Certificate - Composition 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/DVCComposition | *Version*:0.1.0 |
| Draft as of 2025-10-07 | *Computable Name*:DVCComposition |

 
Digital Vaccination Certificate - Composition 

**Usages:**

* Derived from this Profile: [Digital Vaccination Certificate - Composition](StructureDefinition-DVCSDComposition.md)
* Use this Profile: [Digital Vaccination Certificate - Bundle](StructureDefinition-DVCBundle.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/DVCComposition)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Composition](http://hl7.org/fhir/R4/composition.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Composition](http://hl7.org/fhir/R4/composition.html) 

**Summary**

Mandatory: 6 elements
 Must-Support: 9 elements

**Structures**

This structure refers to these other structures:

* [Codeable Concept (IPS)(http://hl7.org/fhir/uv/ips/StructureDefinition/CodeableConcept-uv-ips)](http://hl7.org/fhir/uv/ips/2024Sep/StructureDefinition-CodeableConcept-uv-ips.html)
* [DVC Patient(http://smart.who.int/trust-phw/StructureDefinition/DVCPatient)](StructureDefinition-DVCPatient.md)
* [DVC Immunization(http://smart.who.int/trust-phw/StructureDefinition/DVCImmunization)](StructureDefinition-DVCImmunization.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 2 is sliced based on the values of Composition.section (Closed)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Composition](http://hl7.org/fhir/R4/composition.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Composition](http://hl7.org/fhir/R4/composition.html) 

**Summary**

Mandatory: 6 elements
 Must-Support: 9 elements

**Structures**

This structure refers to these other structures:

* [Codeable Concept (IPS)(http://hl7.org/fhir/uv/ips/StructureDefinition/CodeableConcept-uv-ips)](http://hl7.org/fhir/uv/ips/2024Sep/StructureDefinition-CodeableConcept-uv-ips.html)
* [DVC Patient(http://smart.who.int/trust-phw/StructureDefinition/DVCPatient)](StructureDefinition-DVCPatient.md)
* [DVC Immunization(http://smart.who.int/trust-phw/StructureDefinition/DVCImmunization)](StructureDefinition-DVCImmunization.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 2 is sliced based on the values of Composition.section (Closed)

 

Other representations of profile: [CSV](StructureDefinition-DVCComposition.csv), [Excel](StructureDefinition-DVCComposition.xlsx), [Schematron](StructureDefinition-DVCComposition.sch) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

