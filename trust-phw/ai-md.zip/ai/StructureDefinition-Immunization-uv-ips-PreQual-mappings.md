# DVC - WHO PreQual Immunization for IPS - Mappings - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC - WHO PreQual Immunization for IPS**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-Immunization-uv-ips-PreQual.md) 
*  [Detailed Descriptions](StructureDefinition-Immunization-uv-ips-PreQual-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-Immunization-uv-ips-PreQual.profile.xml.md) 
*  [JSON](StructureDefinition-Immunization-uv-ips-PreQual.profile.json.md) 
*  [TTL](StructureDefinition-Immunization-uv-ips-PreQual.profile.ttl.md) 

## Resource Profile: Immunization-uv-ips-PreQual - Mappings

| |
| :--- |
| Active as of 2025-10-07 |

Mappings for the Immunization-uv-ips-PreQual resource profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

