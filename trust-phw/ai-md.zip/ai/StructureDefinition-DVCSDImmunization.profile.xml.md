# DVC Immunization with Selective Disclosure - XML Representation - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC Immunization with Selective Disclosure**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-DVCSDImmunization.md) 
*  [Detailed Descriptions](StructureDefinition-DVCSDImmunization-definitions.md) 
*  [Mappings](StructureDefinition-DVCSDImmunization-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-DVCSDImmunization.profile.json.md) 
*  [TTL](StructureDefinition-DVCSDImmunization.profile.ttl.md) 

## Resource Profile: DVCSDImmunization - XML Profile

| |
| :--- |
| Active as of 2025-10-07 |

XML representation of the DVCSDImmunization resource profile.

[Raw xml](StructureDefinition-DVCSDImmunization.xml) | [Download](StructureDefinition-DVCSDImmunization.xml)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

