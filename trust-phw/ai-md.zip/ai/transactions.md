# Transactions - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Data Models and Exchange**](data-models-and-exchange.md)
* **Transactions**

Publication Build: This will be filled in by the publication tooling

## Transactions

###  Generate VHL Request

A Holder requests an Issuer to generate a VHL"

* Source: Holder</a>
* Target: Issuer</a>

#### Request Trigger

A Holder wishes to request a VHL from an Issuer.

Optionally: The holder has selected consent and selective disclosure directives.

#### Request Semantics

none defined. up to a content profile to define

#### Request Actions

The Issuer will generate a VHL

#### Response Trigger

Issuer has performed any necceasry document generation, digital signatures and has generated a VHL according to a content profile

#### Response Semantics

none defined. up to content profile to define

#### Response Actions

The Holder accepts the VHL for storage on wallet or other utilization

#### Security Considerations

Depends on the content profile

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

